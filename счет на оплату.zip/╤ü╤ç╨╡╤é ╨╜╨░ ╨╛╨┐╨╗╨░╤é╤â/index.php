<?
require_once("dompdf/dompdf_config.inc.php");


/**
 * Возвращает сумму прописью
 * @author runcore
 * @uses morph(...)
 */
function num2str($num) {
	$nul='ноль';
	$ten=array(
		array('','один','два','три','четыре','пять','шесть','семь', 'восемь','девять'),
		array('','одна','две','три','четыре','пять','шесть','семь', 'восемь','девять'),
	);
	$a20=array('десять','одиннадцать','двенадцать','тринадцать','четырнадцать' ,'пятнадцать','шестнадцать','семнадцать','восемнадцать','девятнадцать');
	$tens=array(2=>'двадцать','тридцать','сорок','пятьдесят','шестьдесят','семьдесят' ,'восемьдесят','девяносто');
	$hundred=array('','сто','двести','триста','четыреста','пятьсот','шестьсот', 'семьсот','восемьсот','девятьсот');
	$unit=array( // Units
		array('копейка' ,'копейки' ,'копеек',	 1),
		array('рубль'   ,'рубля'   ,'рублей'    ,0),
		array('тысяча'  ,'тысячи'  ,'тысяч'     ,1),
		array('миллион' ,'миллиона','миллионов' ,0),
		array('миллиард','милиарда','миллиардов',0),
	);
	list($rub,$kop) = explode('.',sprintf("%015.2f", floatval($num)));
	$out = array();
	if (intval($rub)>0) {
		foreach(str_split($rub,3) as $uk=>$v) {
			if (!intval($v)) continue;
			$uk = sizeof($unit)-$uk-1;
			$gender = $unit[$uk][3];
			list($i1,$i2,$i3) = array_map('intval',str_split($v,1));

			$out[] = $hundred[$i1];
			if ($i2>1) $out[]= $tens[$i2].' '.$ten[$gender][$i3];
			else $out[]= $i2>0 ? $a20[$i3] : $ten[$gender][$i3];
			if ($uk>1) $out[]= morph($v,$unit[$uk][0],$unit[$uk][1],$unit[$uk][2]);
		}
	}
	else $out[] = $nul;
	$out[] = morph(intval($rub), $unit[1][0],$unit[1][1],$unit[1][2]);
	$out[] = $kop.' '.morph($kop,$unit[0][0],$unit[0][1],$unit[0][2]);
	return trim(preg_replace('/ {2,}/', ' ', join(' ',$out)));
}

function morph($n, $f1, $f2, $f5) {
	$n = abs(intval($n)) % 100;
	if ($n>10 && $n<20) return $f5;
	$n = $n % 10;
	if ($n>1 && $n<5) return $f2;
	if ($n==1) return $f1;
	return $f5;
}
$num = num2str(162.16);

$html =
  '<html>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <style>
  	
  	.Section1{text-align: center; width: 70%; margin: 0 auto; font-size: 12px; margin-bottom: 5px;}
  	.Section1 p{margin-bottom: 0px;}
  	.Section2 table{width: 100%; border-collapse: collapse; font-size: 13px;}
  	.Section2 p{margin-bottom: 0px;}
  	.Section2 table td {border: 1px solid; padding: 3px; vertical-align: top;}
  	.Section2 table td.no_b_border{border-bottom: none;}
  	.Section2 table td.no_t_border{border-top: none;}
  	.Section3 p{text-align: center; margin-top:5px; font-size: 13px;}
  	.Section4 h1{font-size: 20px; border-bottom: 2px solid;}
  	.Section4 table.t_info{font-size:12px;width: 100%;}
  	.Section4 table.i_info{font-size:13px;width: 100%;border-collapse: collapse;}
  	.Section4 table.i_info th, .Section4 table.i_info td{border:1px solid;}
  	.Section5{margin-top: 10px; font-weight: 600; font-size:13px;}
  	.Section5 table{width: 100%;}
  	.Section5>div>div.r_info{width: 6%;text-align: right;}
  	.Section6{font-size:13px;}
  	.Section6 p{margin: 5px;}
  	.Section7 {position:relative;}
  	.Section7 table{width: 100%;border-spacing: 17px 0px;font-size:13px; position:relative;z-index:2;}
  	.Section7 table tr.first td{padding-top: 10px;}
  	.Section7 table tr.first td{border-bottom: 1px solid;}
  	.Section7 table tr.first td.name{border-bottom: none;}
  	.Section7 table tr.second td{text-align: center;}
  	.Section7 .print{background: url(/test/post.png) no-repeat;background-size:cover;position:absolute;width:170px;height:170px;bottom:0px; right:30px;z-index:1;}
  </style>
  <body>
  <div class="Section1">
		<p>
			Внимание! Оплата данного счета означает согласие с условиями поставки товара. Уведомление об оплате 
обязательно, в противном случае не гарантируется наличие товара на складе. Товар отпускается по факту
прихода денег на р/с Поставщика, самовывозом, при наличии доверенности и паспорта.
		</p>
	</div>
	<div class="Section2">
		<table>
			<tr>
				<td rowspan="2" colspan="4">Филиал ПАО "БАНК УРАЛСИБ" в г.НОВОСИБИРСК <p>Банк получателя</p></td>
				<td>БИК</td>
				<td class="no_b_border">045004725</td>
			</tr>
			<tr>

				<td>Сч. №<br><br></td>
				<td class="no_t_border">30101810400000000725<br><br></td>
			</tr>
			<tr>
				<td style="width:6%;border-right:none;">ИНН</td>
				<td style="border-left:none;">421702777925</td>
				<td style="width:6%;border-right:none;">КПП</td>
				<td style="border-left:none;">КПП</td>
				<td rowspan="2">Сч. №</td>
				<td rowspan="2">40802810332300000040</td>
			</tr>
			<tr>
				<td colspan="4">Индивидуальный предприниматель Лякин Евгений Владимирович <p>Получатель</p></td>
			</tr>
		</table>
	</div>
	<div class="Section3">
		<p><strong>Внимание !!! счет действителен в течении трех банковских дней.</strong></p>

		<p><strong>Внимание!!! Отдел по работе с корпоративными клиентами с 01.06.2017г. оформляет документы и отгружает товар по новому адресу : Кольцевая 8. Будем рады видеть вас в будние дни с 9 до 18.</strong></p>
		<p><strong>В случае отсутствия товара на складах наш менеджер вышлет вам счёт для оплаты c учётом корректировок.<br>
Товар отсутствующий на складах будет поставлен в согласованный и поставщиком и покупателем день.<br>
Перед оплатой счета рекомендуем связаться с менеджером корпоративного отдела по тел. 8 (3843) 328-058.
</strong></p>
	</div>
	<div class="Section4">
		<h1>Счет на оплату № ЦБ000001063 от 26 июня 2017 г.</h1>
		<table class="t_info">
			<tr>
				<td>Поставщик:</td>
				<td><strong>Индивидуальный предприниматель Лякин Евгений Владимирович
, ИНН 421702777925, 654080 Кемеровская область г.Новокузнецк,ул. Запорожская 69 кв 24, тел.: (3843)328-058</strong></td>
			</tr>
			<tr>
				<td>Грузоотправитель:</td>
				<td><strong>Индивидуальный предприниматель Лякин Евгений Владимирович
, ИНН 421702777925, 654080 Кемеровская область г.Новокузнецк,ул. Запорожская 69 кв 24, тел.: (3843)328-058</strong></td>
			</tr>
		</table><br>
		<table class="i_info">
			<thead>
				<tr>
					<th>№</th>
					<th>Артикул</th>
					<th>Товары (работы, услуги)</th>					
					<th>Кол-во</th>
					<th>Ед.</th>
					<th>Цена</th>
					<th>Сумма</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td align="center">1</td>
					<td>423871</td>
					<td>Дюбель рамный HILTI HRD-H 10*80мм</td>					
					<td align="right">4</td>
					<td>шт</td>
					<td align="right">40.54</td>
					<td align="right">162.16</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div class="Section5">
		<table>
			<tr>
				<td align="right" style="width: 90%;">Итого:</td>
				<td style="width: 10%;" align="right">162.16</td>
			</tr>	
			<tr>
				<td align="right" style="width: 90%;">В том числе НДС:</td>
				<td style="width: 10%;" align="right">24.74</td>
			</tr>
			<tr>
				<td align="right" style="width: 90%;">Всего к оплате:</td>
				<td style="width: 10%;" align="right">162.16</td>
			</tr>
		</table>
	</div>
	<div class="Section6">
		<p>Всего наименований 1, на сумму 162,16 руб.</p>
		<p><strong>'.$num.'</strong></p>
	</div>
	<hr>
	<div class="Section7">
		<table>
			<tr class="first">
				<td class="name">Руководитель</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr class="second">
				<td></td>
				<td>должность</td>
				<td>подпись</td>
				<td>расшифровка подписи</td>
			</tr>
			<tr class="first">
				<td class="name">Главный (старший) бухгалтер</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr class="second">
				<td></td>
				<td>должность</td>
				<td>подпись</td>
				<td>расшифровка подписи</td>
			</tr>
			<tr class="first">
				<td class="name">Ответственный</td>
				<td class="name"></td>
				<td></td>
				<td></td>
			</tr>
			<tr class="second">
				<td></td>
				<td></td>
				<td>подпись</td>
				<td>расшифровка подписи</td>
			</tr>
		</table>
		<div class="print"></div>
	</div>
  </body></html>';


// echo $html;
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->render();
$dompdf->stream('mypdf.pdf');

$order_number = '10';




?>

<style>
	
</style>