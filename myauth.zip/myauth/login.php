<?php
require('db.php');
require('function.php');

	$data = $_POST;
	
	if(!isset($_COOKIE['username'])){
		if(isset($data['auth'])){
			$errors = array();
			$login = strip_tags(trim($data['login']));
	 		$password = strip_tags($data['password']);
	 		$password = sha1($password);
	 		
	 		if(!empty($login) && !empty($password)){
		 		$query = "SELECT user_id, login, password FROM reg_users WHERE login='$login'";
		 		
		 		$res = $mydb->query($query);
		 		if($res->num_rows > 0){
			 		//если логин существует
			 		$row=$res->fetch_assoc();
			 		if($row['password'] == $password){
				 		//если пароль правильный
				 		setcookie('user_id', $row['user_id'], time() + (60*60*24*30));
				 		setcookie('username', $row['login'], time() + (60*60*24*30));
				 		
				 		$home_url = 'http://' . $_SERVER['HTTP_HOST'];
				 		header('Location: '. $home_url);
				 		
			 		}else{
				 		$errors[] = 'Неверное имя пользователя или пароль!';
			 		}
		 		}else{
			 		$errors[] = 'Неверное имя пользователя или пароль!';
		 		}
	 		}else{
		 		$errors[] = 'Введите логин и пароль!';
	 		}
	 		if(!empty($errors)){
		 		echo "<div id='errors'>".array_shift($errors)."</div>";
	 		}
	 		
	 		
		}
	}
	
?>
<form action="<?=$_SERVER['PHP_SELF'];?>" method="post">
	<p><strong>Логин: </strong><input type="text" name="login" value="<?=@$data['login']?>"></p>
	<p><strong>Пароль: </strong><input type="password" name="password"></p>
	<p><input type="submit" value="Авторизоваться" name="auth"></p>
</form>