<?php
require('db.php');
require('function.php');
?>
<?
	$data = $_POST;

	if(isset($data['do_signup'])){
		
		//Проверка на ошибки
		$errors = array();

		if(trim($data['login']) == ''){
			$errors[] = 'Введите логин!';
 		}
 		if(trim($data['email']) == ''){
	 		$errors[] = 'Введите Email!';
 		}
 		if($data['password'] == ''){
	 		$errors[] = 'Введите пароль!';
 		}
		if($data['password_2'] != $data['password']){
	 		$errors[] = 'Повторный пароль введен неверно!';
 		}
 		$query = "SELECT * FROM reg_users WHERE login='".$data['login']."'";
 		$res = $mydb->query($query);
 		if($res->num_rows > 0){
	 		$errors[] = 'Пользователь с таким логином уже существует!';
 		}
 		$query = "SELECT * FROM reg_users WHERE email='".$data['email']."'";
 		$res = $mydb->query($query);
 		if($res->num_rows > 0){
	 		$errors[] = 'Пользователь с таким Email уже существует!';
 		}
 		
 		if(empty($errors)){
	 		//Регистрируем пользователя
	 		$login = strip_tags(trim($data['login']));
	 		$email = strip_tags(trim($data['email']));
	 		$password = strip_tags($data['password']);
	 		$password = sha1($password);
	 		
			$query = "INSERT INTO reg_users (user_id, login, email, password) VALUES (NULL, '$login', '$email', '$password')";
	 		if($mydb->query($query)){
		 		setcookie('username', $login, time() + (60*60*24*30));	
		 		$home_url = 'http://' . $_SERVER['HTTP_HOST'];
		 		header('Location: '. $home_url);
	 		}
 		}else{
	 		echo "<div id='errors'>".array_shift($errors)."</div>";
 		}
	}
?>


<form action="<?echo $_SERVER['PHP_SELF'];?>" method="post">
	<p><strong>Логин: </strong><input type="text" name="login" value="<?=@$data['login']?>"></p>
	<p><strong>Email: </strong><input type="email" name="email" value="<?=@$data['email']?>"></p>
	<p><strong>Пароль: </strong><input type="password" name="password"></p>
	<p><strong>Еще раз: </strong><input type="password" name="password_2"></p>	
	<p><input type="submit" name="do_signup" value="Зарегистрироваться"></p>
</form>