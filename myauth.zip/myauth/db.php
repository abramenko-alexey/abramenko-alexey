<?
$basename='cl71854_db';
$host='localhost'; 
$user='cl71854_db';
$passw='Asdqwe!';
$mydb=new mysqli($host,$user,$passw,$basename);
$mydb->query("SET NAMES 'utf8'");
?>