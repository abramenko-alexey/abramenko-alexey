<?
require('db.php');
require('function.php');
?>
<?if(isset($_COOKIE['username'])){?>
<p>Добрый день, <?=$_COOKIE['username']?></p>
<p><a href="/logout.php">Выйти</a></p>

<?}else{?>

<a href="/login.php">Авторизоваться</a>
<a href="/reg.php">Зарегистрироваться</a>

<?}?>